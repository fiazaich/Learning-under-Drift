# Regional Feedback Results Dashboard

Open this file first. The detailed CSVs are appendices unless you need row-level evidence.

## Bottom Line

- Raw-rate diagnostics answer the deployable monitoring question: what can be watched directly in production.
- Excess-rate diagnostics answer the controlled attribution question: what changes beyond the seed-matched mu=0 baseline.
- Leave-one-mu-out regressions are stress tests, not the primary diagnostic.
- Step-level diagnostics currently show the clearest risk-shift signal; seed-level within-mu associations are much weaker.

## Does Feedback Move Risk-Relevant Quantities?

| mu | V_T_mean | Delta_rep_T_mean | Mean_abs_delta_y_T_mean | Mean_abs_delta_error_T_mean | Mean_abs_delta_loss_T_mean |
| --- | --- | --- | --- | --- | --- |
| 0.000 | 1485.754 | 2682.794 | 29.776 | 31.299 | 2.623e+04 |
| 0.050 | 2632.074 | 3483.200 | 68.058 | 33.856 | 3.167e+04 |
| 0.100 | 5082.420 | 4750.336 | 113.557 | 40.020 | 4.053e+04 |
| 0.200 | 1.581e+04 | 1.534e+04 | 199.620 | 55.340 | 6.362e+04 |

## Operational Raw-Rate Diagnostics

Best channel per target by average within-mu Spearman rank.

| target | channel | mean_spearman | median_spearman | fraction_positive_spearman | average_rank_across_mu |
| --- | --- | --- | --- | --- | --- |
| V_T | blind | 0.021 | 0.036 | 0.500 | 2.750 |
| Delta_rep_T | task | 0.073 | 0.048 | 0.500 | 3.250 |
| Delta_sam_T | task_no_cost | 0.261 | 0.194 | 1.000 | 2.000 |
| Eval_within_step_drift_T | coarse | 0.133 | 0.236 | 0.750 | 2.500 |
| Mean_abs_delta_loss_T | task_no_group | 0.182 | 0.182 | 0.500 | 2.500 |
| Mean_abs_delta_error_T | task_no_cost | 0.230 | 0.242 | 1.000 | 2.500 |

## Controlled Excess-Rate Diagnostics

Best channel per target using seed-matched mu=0 baseline subtraction.

| target | channel | mean_spearman | median_spearman | fraction_positive_spearman | average_rank_across_mu |
| --- | --- | --- | --- | --- | --- |
| V_T | task_no_cost | 0.099 | 0.164 | 0.667 | 2.333 |
| Delta_rep_T | blind | 0.552 | 0.527 | 1.000 | 1.000 |

## Per-Step FR vs V_T

This uses all positive-mu transitions, so it has many more observations than seed-level summaries.

| channel | n_steps | spearman | pearson | slope |
| --- | --- | --- | --- | --- |
| task_no_group | 570 | 0.578 | 0.447 | 5.128e+04 |
| task | 570 | 0.573 | 0.452 | 5.300e+04 |
| task_no_cost | 570 | 0.569 | 0.435 | 4.706e+04 |
| blind | 570 | 0.462 | 0.416 | 5.189e+05 |
| task_no_qty | 570 | 0.304 | 0.346 | 4.917e+04 |
| coarse | 570 | 0.162 | 0.276 | 3.781e+04 |

## Across-Mu Condition Mean Trends

These show monotone regime-level movement. They are useful operationally but are not within-regime prediction.

| target | channel | spearman_target_mean_with_predictor_mean | pearson_target_mean_with_predictor_mean |
| --- | --- | --- | --- |
| V_T | blind | 1.000 | 0.912 |
| Delta_rep_T | blind | 1.000 | 0.876 |
| Mean_abs_delta_loss_T | blind | 1.000 | 0.958 |
| Mean_abs_delta_error_T | blind | 1.000 | 0.949 |

## Stress Test

Best leave-one-mu-out rows. This is not the operational monitor.

| target | model_name | mean_heldout_rmse | mean_heldout_r2 |
| --- | --- | --- | --- |
| Delta_sam_T | single_channel:blind | 2377.703 | -0.023 |
| Delta_sam_T | single_channel:task_no_cost | 2381.692 | -0.023 |
| Delta_sam_T | single_channel:task_no_group | 2404.109 | -0.046 |
| Delta_sam_T | single_channel:task | 2413.233 | -0.052 |
| Delta_rep_T | mu_controlled:task_no_cost | 3503.876 | -0.057 |

## File Map

| File | Use |
| --- | --- |
| `RESULTS_DASHBOARD.md` | Start here. Human-readable summary. |
| `table_operational_raw_rate_diagnostics.csv` | Main deployable raw-rate summary. |
| `table_5_regression_diagnostics.csv` | Main controlled excess-rate summary. |
| `regional_feedback_step_diagnostics.csv` | Per-transition FR vs risk/motion diagnostics. |
| `regional_feedback_summary.csv` | Main metrics by mu. |
| `regional_feedback_rounds.csv` | Round-level raw data. Large/detail file. |
| `regional_feedback_results_by_seed.csv` | Condition/seed-level raw data. |
| `appendix_*` and `regional_feedback_regressions_cv.csv` | Stress tests / appendix only. |
